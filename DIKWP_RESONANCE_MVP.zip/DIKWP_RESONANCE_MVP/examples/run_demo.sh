#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
PYTHONPATH=src python -m dikwp_resonance.cli --trials 12000 --seed 7152026
PYTHONPATH=src pytest -q
