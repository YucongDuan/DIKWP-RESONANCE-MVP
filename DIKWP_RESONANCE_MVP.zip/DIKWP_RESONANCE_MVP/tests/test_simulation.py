import json
from pathlib import Path

from dikwp_resonance.models import ChannelProfile, EntityProfile, InteractionCase
from dikwp_resonance.simulation import run_case_suite, simulate_forecast_events

ROOT = Path(__file__).resolve().parents[1]


def load_suite():
    entities = {x["entity_id"]: EntityProfile.from_mapping(x) for x in json.loads((ROOT / "data/entity_profiles.json").read_text(encoding="utf-8"))}
    channels = {x["channel_id"]: ChannelProfile.from_mapping(x) for x in json.loads((ROOT / "data/channel_profiles.json").read_text(encoding="utf-8"))}
    cases = [InteractionCase.from_mapping(x) for x in json.loads((ROOT / "data/interaction_cases.json").read_text(encoding="utf-8"))]
    return entities, channels, cases


def test_suite_runs_and_is_deterministic():
    entities, channels, cases = load_suite()
    a = run_case_suite(cases, entities, channels, 123)
    b = run_case_suite(cases, entities, channels, 123)
    assert [x.to_dict() for x in a] == [x.to_dict() for x in b]
    assert len(a) == len(cases)


def test_forecast_bounds():
    specs = json.loads((ROOT / "config/forecast_specs.json").read_text(encoding="utf-8"))
    rows, meta = simulate_forecast_events(500, 123, specs)
    assert meta["trials"] == 500
    assert all(0 <= x["probability_by_close"] <= 1 for x in rows)
    assert len(rows) == len(specs)
