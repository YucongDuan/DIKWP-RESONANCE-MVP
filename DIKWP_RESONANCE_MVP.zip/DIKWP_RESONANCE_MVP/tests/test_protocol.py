from dikwp_resonance.protocol import demo_packet


def test_packet_has_dikwp_and_hash():
    p = demo_packet("case", "a", "b", "c")
    for k in ["D", "I", "K", "W", "P", "reply_schema", "sha256"]:
        assert k in p
    assert len(p["sha256"]) == 64
