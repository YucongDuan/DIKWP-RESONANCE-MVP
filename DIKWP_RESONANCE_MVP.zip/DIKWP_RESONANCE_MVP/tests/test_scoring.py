import json
from pathlib import Path

from dikwp_resonance.models import ChannelProfile, EntityProfile, InteractionCase
from dikwp_resonance.scoring import STAGE_ORDER, channel_compatibility, classify_stage, initial_metrics, select_channel

ROOT = Path(__file__).resolve().parents[1]


def load():
    entities = {x["entity_id"]: EntityProfile.from_mapping(x) for x in json.loads((ROOT / "data/entity_profiles.json").read_text(encoding="utf-8"))}
    channels = {x["channel_id"]: ChannelProfile.from_mapping(x) for x in json.loads((ROOT / "data/channel_profiles.json").read_text(encoding="utf-8"))}
    cases = [InteractionCase.from_mapping(x) for x in json.loads((ROOT / "data/interaction_cases.json").read_text(encoding="utf-8"))]
    return entities, channels, cases


def test_channel_scores_bounded():
    entities, channels, cases = load()
    case = cases[0]
    metrics = channel_compatibility(entities[case.sender_id], entities[case.receiver_id], channels[case.candidate_channels[0]])
    assert all(0 <= v <= 1 for v in metrics.values())


def test_human_ai_channel_is_symbolic():
    entities, channels, cases = load()
    case = cases[0]
    channel, _ = select_channel(entities[case.sender_id], entities[case.receiver_id], case, channels)
    assert channel.channel_id == "symbolic_packet"


def test_hard_cap_applied():
    entities, channels, cases = load()
    case = next(x for x in cases if x.case_id == "earth_interstellar_beacon")
    metrics = {k: 0.95 for k in "DIKWPRHS"}
    metrics.update({"institution": 0.95, "meta_protocol": 0.95})
    stage, _, _ = classify_stage(metrics, case)
    assert STAGE_ORDER.index(stage) <= STAGE_ORDER.index("Q4_REFERENCE")


def test_initial_metrics_bounded():
    entities, channels, cases = load()
    case = cases[2]
    ch, compat = select_channel(entities[case.sender_id], entities[case.receiver_id], case, channels)
    metrics = initial_metrics(entities[case.sender_id], entities[case.receiver_id], ch, case, compat)
    assert set(metrics) == set("DIKWPRHS")
    assert all(0 <= v <= 1 for v in metrics.values())
