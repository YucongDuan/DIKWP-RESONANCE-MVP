from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any, Dict, List, Mapping, Optional


@dataclass
class EntityProfile:
    entity_id: str
    name_zh: str
    category: str
    description: str
    life_phase: str
    consciousness_status: str
    civilization_phase: str
    transmit: Dict[str, float]
    receive: Dict[str, float]
    dimensions: Dict[str, float]
    safety: Dict[str, float]
    notes: List[str] = field(default_factory=list)

    @classmethod
    def from_mapping(cls, value: Mapping[str, Any]) -> "EntityProfile":
        return cls(
            entity_id=str(value["entity_id"]),
            name_zh=str(value["name_zh"]),
            category=str(value.get("category", "unknown")),
            description=str(value.get("description", "")),
            life_phase=str(value.get("life_phase", "unknown")),
            consciousness_status=str(value.get("consciousness_status", "unknown")),
            civilization_phase=str(value.get("civilization_phase", "unknown")),
            transmit={k: float(v) for k, v in value.get("transmit", {}).items()},
            receive={k: float(v) for k, v in value.get("receive", {}).items()},
            dimensions={k: float(v) for k, v in value.get("dimensions", {}).items()},
            safety={k: float(v) for k, v in value.get("safety", {}).items()},
            notes=list(value.get("notes", [])),
        )

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class ChannelProfile:
    channel_id: str
    name_zh: str
    modality: str
    description: str
    bandwidth: float
    range: float
    reliability: float
    latency: float
    energy_efficiency: float
    reversibility: float
    invasiveness: float
    persistence: float
    broadcastness: float
    notes: List[str] = field(default_factory=list)

    @classmethod
    def from_mapping(cls, value: Mapping[str, Any]) -> "ChannelProfile":
        return cls(
            channel_id=str(value["channel_id"]),
            name_zh=str(value["name_zh"]),
            modality=str(value["modality"]),
            description=str(value.get("description", "")),
            bandwidth=float(value.get("bandwidth", 0.0)),
            range=float(value.get("range", 0.0)),
            reliability=float(value.get("reliability", 0.0)),
            latency=float(value.get("latency", 0.0)),
            energy_efficiency=float(value.get("energy_efficiency", 0.0)),
            reversibility=float(value.get("reversibility", 0.0)),
            invasiveness=float(value.get("invasiveness", 0.0)),
            persistence=float(value.get("persistence", 0.0)),
            broadcastness=float(value.get("broadcastness", 0.0)),
            notes=list(value.get("notes", [])),
        )

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class InteractionCase:
    case_id: str
    name_zh: str
    description: str
    sender_id: str
    receiver_id: str
    candidate_channels: List[str]
    prior: Dict[str, float]
    governance: Dict[str, float]
    probe_budget: int
    time_horizon_rounds: int
    hard_stage_cap: Optional[str] = None
    notes: List[str] = field(default_factory=list)

    @classmethod
    def from_mapping(cls, value: Mapping[str, Any]) -> "InteractionCase":
        return cls(
            case_id=str(value["case_id"]),
            name_zh=str(value["name_zh"]),
            description=str(value.get("description", "")),
            sender_id=str(value["sender_id"]),
            receiver_id=str(value["receiver_id"]),
            candidate_channels=list(value.get("candidate_channels", [])),
            prior={k: float(v) for k, v in value.get("prior", {}).items()},
            governance={k: float(v) for k, v in value.get("governance", {}).items()},
            probe_budget=int(value.get("probe_budget", 0)),
            time_horizon_rounds=int(value.get("time_horizon_rounds", 0)),
            hard_stage_cap=value.get("hard_stage_cap"),
            notes=list(value.get("notes", [])),
        )

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class CommunicationAssessment:
    case_id: str
    case_name_zh: str
    sender: str
    receiver: str
    selected_channel: str
    selected_channel_zh: str
    metrics: Dict[str, float]
    stage: str
    stage_zh: str
    closure: float
    bottleneck: str
    bottleneck_zh: str
    semantic_efficiency: float
    safety_gate: str
    trace: List[Dict[str, Any]]
    notes: List[str]

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class ForecastContract:
    forecast_id: str
    question_zh: str
    close_year: int
    probability: float
    settlement_rule: str
    update_triggers: List[str]
    action_thresholds: List[Dict[str, Any]]
    interpretation: str

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)
