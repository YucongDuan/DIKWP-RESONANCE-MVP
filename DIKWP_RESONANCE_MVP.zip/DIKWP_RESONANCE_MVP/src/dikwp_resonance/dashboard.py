from __future__ import annotations

import html
import json
from pathlib import Path
from typing import Any, Dict, List


def _pct(x: float) -> str:
    return f"{100*x:.1f}%"


def render_dashboard(assessments: List[Dict[str, Any]], forecasts: List[Dict[str, Any]], packet: Dict[str, Any], out_path: Path) -> None:
    cards = []
    gate_labels = {'CONTROLLED_TRIAL': '受控试验', 'ADVISORY_ONLY': '仅建议／观察', 'BLOCKED': '禁止'}
    for a in assessments:
        metric_rows = "".join(
            f"<tr><td>{m}</td><td>{_pct(v)}</td></tr>" for m, v in a["metrics"].items()
        )
        cards.append(f"""
        <section class='card'>
          <h3>{html.escape(a['case_name_zh'])}</h3>
          <p class='meta'>{html.escape(a['sender'])} → {html.escape(a['receiver'])}｜{html.escape(a['selected_channel_zh'])}</p>
          <div class='stage'>{html.escape(a['stage_zh'])}</div>
          <p>闭合度：<b>{_pct(a['closure'])}</b>；语义效率：<b>{_pct(a['semantic_efficiency'])}</b>；安全门：<b>{html.escape(gate_labels.get(a['safety_gate'], a['safety_gate']))}</b></p>
          <p>当前瓶颈：{html.escape(a['bottleneck_zh'])}</p>
          <table><tbody>{metric_rows}</tbody></table>
        </section>""")
    forecast_rows = "".join(
        f"<tr><td>{html.escape(f['question_zh'])}</td><td>{f['close_year']}</td><td>{_pct(f['probability_by_close'])}</td><td>{f['median_year_if_occurs'] or '—'}</td></tr>"
        for f in forecasts
    )
    packet_json = html.escape(json.dumps(packet, ensure_ascii=False, indent=2))
    stage_list = [
        "Q0 未区分耦合", "Q1 可检测通量", "Q2 条件性信号", "Q3 稳定代码", "Q4 共同指称",
        "Q5 因果模型交换", "Q6 目的与边界协商", "Q7 互惠理解", "Q8 身份与制度互操作", "Q9 共生元协议",
    ]
    stages = "".join(f"<li>{s}</li>" for s in stage_list)
    doc = f"""<!doctype html>
<html lang='zh-CN'>
<head>
<meta charset='utf-8'>
<meta name='viewport' content='width=device-width,initial-scale=1'>
<title>DIKWP-RESONANCE Dashboard</title>
<style>
body{{font-family:system-ui,-apple-system,'Noto Sans CJK SC',sans-serif;margin:0;background:#f4f5f7;color:#1f2937}}
header{{padding:34px 6vw;background:#fff;border-bottom:1px solid #ddd}}
main{{padding:24px 6vw 60px}}
h1{{margin:0 0 8px;font-size:2rem}}h2{{margin-top:36px}}.lead{{max-width:980px;line-height:1.8}}
.grid{{display:grid;grid-template-columns:repeat(auto-fit,minmax(310px,1fr));gap:16px}}
.card{{background:white;border:1px solid #ddd;border-radius:12px;padding:18px;box-shadow:0 2px 8px rgba(0,0,0,.04)}}
.meta{{color:#6b7280}}.stage{{font-size:1.15rem;font-weight:700;margin:12px 0}}
table{{width:100%;border-collapse:collapse}}td,th{{border-bottom:1px solid #eee;padding:8px;text-align:left;vertical-align:top}}
pre{{white-space:pre-wrap;background:#111827;color:#f9fafb;padding:18px;border-radius:10px;overflow:auto}}
.warning{{background:#fff7ed;border-left:4px solid #999;padding:14px;line-height:1.7}}
.ladder{{columns:2;line-height:1.9}}
</style>
</head>
<body>
<header>
<h1>DIKWP-RESONANCE</h1>
<p>跨生命—跨文明沟通演化与能量—信息—意义转换系统｜离线演示仪表盘</p>
</header>
<main>
<p class='lead'><b>核心判断：</b>沟通不是把“意义”装进能量载体后搬运到另一端，而是在能量、时延和边界约束下，通过可反驳、可修复的双向干预，共同构造一个能支持预测、行动、拒绝和承诺的共享因果空间。</p>
<div class='warning'>所有分数、年份和概率均为合成原型输出，不构成对真实物种、AI系统、脑机接口或外星文明的事实认证。Q等级不证明意识、人格或善意。</div>
<h2>沟通相位梯</h2><ol class='ladder'>{stages}</ol>
<h2>十类跨实体沟通演示</h2><div class='grid'>{''.join(cards)}</div>
<h2>预测合同的合成结算窗口</h2>
<table><thead><tr><th>可结算事件</th><th>窗口</th><th>种子概率</th><th>若发生的中位年份</th></tr></thead><tbody>{forecast_rows}</tbody></table>
<h2>DIKWP证明携带型消息包</h2><pre>{packet_json}</pre>
</main></body></html>"""
    out_path.write_text(doc, encoding="utf-8")
