from __future__ import annotations

import argparse
import csv
import hashlib
import json
import platform
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Iterable, List

from .dashboard import render_dashboard
from .forecasts import build_contracts
from .models import ChannelProfile, EntityProfile, InteractionCase
from .protocol import demo_packet
from .simulation import run_case_suite, simulate_forecast_events


def read_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def write_json(path: Path, value: Any) -> None:
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding="utf-8")


def write_csv(path: Path, rows: List[Dict[str, Any]], fields: Iterable[str]) -> None:
    with path.open("w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(fields))
        writer.writeheader()
        for row in rows:
            writer.writerow({k: row.get(k) for k in writer.fieldnames})


def manifest(root: Path) -> Dict[str, str]:
    result: Dict[str, str] = {}
    for path in sorted(root.rglob("*")):
        if path.is_file() and path.name != "MANIFEST.sha256":
            result[str(path.relative_to(root))] = hashlib.sha256(path.read_bytes()).hexdigest()
    return result


def main() -> int:
    parser = argparse.ArgumentParser(description="Run DIKWP-RESONANCE MVP")
    parser.add_argument("--trials", type=int, default=12000)
    parser.add_argument("--seed", type=int, default=7152026)
    args = parser.parse_args()

    root = Path(__file__).resolve().parents[2]
    outputs = root / "outputs"
    outputs.mkdir(exist_ok=True)
    entities = {x["entity_id"]: EntityProfile.from_mapping(x) for x in read_json(root / "data" / "entity_profiles.json")}
    channels = {x["channel_id"]: ChannelProfile.from_mapping(x) for x in read_json(root / "data" / "channel_profiles.json")}
    cases = [InteractionCase.from_mapping(x) for x in read_json(root / "data" / "interaction_cases.json")]
    specs = read_json(root / "config" / "forecast_specs.json")

    assessments = [a.to_dict() for a in run_case_suite(cases, entities, channels, args.seed)]
    forecasts, forecast_summary = simulate_forecast_events(args.trials, args.seed + 37, specs)
    contracts = build_contracts(forecasts)
    packet = demo_packet(cases[0].case_id, cases[0].sender_id, cases[0].receiver_id, assessments[0]["selected_channel"])

    write_json(outputs / "communication_assessments.json", assessments)
    write_json(outputs / "forecast_summary.json", {"meta": forecast_summary, "events": forecasts})
    write_json(outputs / "forecast_contracts.json", contracts)
    write_json(outputs / "demo_dikwp_packet.json", packet)
    write_csv(outputs / "communication_assessments.csv", [
        {
            "case_id": a["case_id"], "case_name_zh": a["case_name_zh"], "sender": a["sender"], "receiver": a["receiver"],
            "channel": a["selected_channel_zh"], "stage": a["stage_zh"], "closure": a["closure"],
            "semantic_efficiency": a["semantic_efficiency"], "bottleneck": a["bottleneck_zh"], "safety_gate": a["safety_gate"],
        } for a in assessments
    ], ["case_id", "case_name_zh", "sender", "receiver", "channel", "stage", "closure", "semantic_efficiency", "bottleneck", "safety_gate"])
    write_csv(outputs / "forecast_events.csv", forecasts, [
        "event_id", "question_zh", "close_year", "probability_by_close", "probability_ever_in_model",
        "p10_year_if_occurs", "median_year_if_occurs", "p90_year_if_occurs", "settlement_rule", "interpretation",
    ])
    render_dashboard(assessments, forecasts, packet, outputs / "dashboard.html")

    proof = {
        "system": "DIKWP-RESONANCE",
        "version": "1.0.0",
        "executed_at": datetime.now(timezone.utc).isoformat(),
        "python": sys.version,
        "platform": platform.platform(),
        "seed": args.seed,
        "trials": args.trials,
        "cases": len(cases),
        "outputs": [p.name for p in sorted(outputs.iterdir()) if p.is_file()],
    }
    write_json(root / "RUN_PROOF.json", proof)
    hashes = manifest(root)
    (root / "MANIFEST.sha256").write_text("\n".join(f"{digest}  {name}" for name, digest in hashes.items()) + "\n", encoding="utf-8")

    print(json.dumps({
        "cases": len(assessments),
        "forecast_events": len(forecasts),
        "trials": args.trials,
        "dashboard": str(outputs / "dashboard.html"),
    }, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
