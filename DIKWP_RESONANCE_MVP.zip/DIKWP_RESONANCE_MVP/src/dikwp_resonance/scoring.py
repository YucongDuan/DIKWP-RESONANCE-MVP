from __future__ import annotations

import math
from typing import Dict, Iterable, Mapping, Tuple

from .models import ChannelProfile, EntityProfile, InteractionCase


def clamp(value: float, low: float = 0.0, high: float = 1.0) -> float:
    return max(low, min(high, float(value)))


def geometric_mean(values: Iterable[float], floor: float = 1e-6) -> float:
    vals = [max(floor, clamp(v)) for v in values]
    if not vals:
        return 0.0
    return math.exp(sum(math.log(v) for v in vals) / len(vals))


def harmonic_mean(values: Iterable[float], floor: float = 1e-6) -> float:
    vals = [max(floor, clamp(v)) for v in values]
    if not vals:
        return 0.0
    return len(vals) / sum(1.0 / v for v in vals)


STAGES = {
    "Q0_COUPLING": "Q0 未区分耦合",
    "Q1_FLUX": "Q1 可检测通量",
    "Q2_SIGNAL": "Q2 条件性信号",
    "Q3_CODE": "Q3 稳定代码",
    "Q4_REFERENCE": "Q4 共同指称",
    "Q5_MODEL": "Q5 因果模型交换",
    "Q6_PURPOSE": "Q6 目的与边界协商",
    "Q7_RECIPROCAL": "Q7 互惠理解",
    "Q8_INSTITUTION": "Q8 身份与制度互操作",
    "Q9_COEVOLUTION": "Q9 共生元协议／共同演化",
}

STAGE_ORDER = list(STAGES)

METRIC_ZH = {
    "D": "D 数据可区分性",
    "I": "I 信息结构",
    "K": "K 因果知识对齐",
    "W": "W 长期价值与伤害校准",
    "P": "P 目的、同意与承诺",
    "R": "R 互惠更新",
    "H": "H 修复与纠错",
    "S": "S 安全、身份与边界",
}


def channel_compatibility(sender: EntityProfile, receiver: EntityProfile, channel: ChannelProfile) -> Dict[str, float]:
    tx = sender.transmit.get(channel.modality, 0.0)
    rx = receiver.receive.get(channel.modality, 0.0)
    physical = geometric_mean([tx, rx, channel.reliability, 0.55 + 0.45 * channel.bandwidth])
    temporal = geometric_mean([1.0 - channel.latency, sender.dimensions.get("temporal_adaptability", 0.5), receiver.dimensions.get("temporal_adaptability", 0.5)])
    energetic = geometric_mean([channel.energy_efficiency, sender.dimensions.get("energy_budget", 0.5), receiver.dimensions.get("energy_budget", 0.5)])
    boundary = geometric_mean([channel.reversibility, 1.0 - channel.invasiveness, sender.safety.get("boundary_integrity", 0.5), receiver.safety.get("boundary_integrity", 0.5)])
    return {
        "physical": clamp(physical),
        "temporal": clamp(temporal),
        "energetic": clamp(energetic),
        "boundary": clamp(boundary),
        "total": clamp(0.46 * physical + 0.18 * temporal + 0.16 * energetic + 0.20 * boundary),
    }


def select_channel(sender: EntityProfile, receiver: EntityProfile, case: InteractionCase, channels: Mapping[str, ChannelProfile]) -> Tuple[ChannelProfile, Dict[str, float]]:
    best: ChannelProfile | None = None
    best_metrics: Dict[str, float] = {}
    best_score = -1.0
    for cid in case.candidate_channels:
        channel = channels[cid]
        metrics = channel_compatibility(sender, receiver, channel)
        governance_bonus = geometric_mean([
            case.governance.get("authorization", 0.5),
            case.governance.get("monitoring", 0.5),
            case.governance.get("rollback", 0.5),
        ])
        score = 0.86 * metrics["total"] + 0.14 * governance_bonus
        if score > best_score:
            best = channel
            best_metrics = metrics
            best_score = score
    if best is None:
        raise ValueError(f"No candidate channel for {case.case_id}")
    return best, best_metrics


def initial_metrics(sender: EntityProfile, receiver: EntityProfile, channel: ChannelProfile, case: InteractionCase, compat: Mapping[str, float]) -> Dict[str, float]:
    p = case.prior
    g = case.governance
    sender_d = sender.dimensions
    receiver_d = receiver.dimensions
    D = geometric_mean([
        compat["physical"], p.get("provenance", 0.2), p.get("synchronization", 0.2),
        0.35 + 0.65 * channel.reliability,
    ])
    I = geometric_mean([
        p.get("pattern_structure", 0.15), p.get("context_covariation", 0.15),
        p.get("contingency", 0.15), 0.25 + 0.75 * channel.bandwidth,
    ])
    K = geometric_mean([
        p.get("causal_grounding", 0.08), p.get("ontology_overlap", 0.08),
        p.get("predictive_transfer", 0.08),
        sender_d.get("causal_learning", 0.4), receiver_d.get("causal_learning", 0.4),
    ])
    W = geometric_mean([
        g.get("welfare_review", 0.3), g.get("long_horizon_review", 0.3),
        g.get("uncertainty_calibration", 0.3), channel.reversibility,
    ])
    P = geometric_mean([
        p.get("intent_legibility", 0.08), p.get("consent_or_viability", 0.08),
        p.get("commitment_consistency", 0.08), g.get("authorization", 0.3),
    ])
    R = geometric_mean([
        p.get("feedback", 0.08), p.get("turn_taking", 0.08),
        sender_d.get("model_update", 0.4), receiver_d.get("model_update", 0.4),
        compat["temporal"],
    ])
    H = geometric_mean([
        p.get("error_correction", 0.12), p.get("clarification", 0.12),
        g.get("rollback", 0.3), channel.reversibility,
    ])
    S = geometric_mean([
        g.get("monitoring", 0.3), g.get("identity_integrity", 0.3),
        g.get("information_hazard_control", 0.3), compat["boundary"],
        sender.safety.get("non_coercion", 0.5), receiver.safety.get("non_coercion", 0.5),
    ])
    return {k: round(clamp(v), 5) for k, v in {"D": D, "I": I, "K": K, "W": W, "P": P, "R": R, "H": H, "S": S}.items()}


def classify_stage(metrics: Mapping[str, float], case: InteractionCase) -> Tuple[str, float, str]:
    d, i, k, w, p, r, h, s = [metrics[x] for x in "DIKWPRHS"]
    closure = min(d, i, k, w, p, r, h, s)
    stage = "Q0_COUPLING"
    if d >= 0.24:
        stage = "Q1_FLUX"
    if d >= 0.38 and i >= 0.28:
        stage = "Q2_SIGNAL"
    if i >= 0.48 and h >= 0.42:
        stage = "Q3_CODE"
    if k >= 0.43 and i >= 0.53 and h >= 0.48:
        stage = "Q4_REFERENCE"
    if k >= 0.60 and r >= 0.50 and h >= 0.53:
        stage = "Q5_MODEL"
    if p >= 0.53 and w >= 0.53 and s >= 0.55 and k >= 0.55:
        stage = "Q6_PURPOSE"
    if min(k, p, r, h, s) >= 0.64:
        stage = "Q7_RECIPROCAL"
    if min(k, p, r, h, s) >= 0.72 and metrics.get("institution", 0.0) >= 0.60:
        stage = "Q8_INSTITUTION"
    if min(k, p, r, h, s) >= 0.80 and metrics.get("meta_protocol", 0.0) >= 0.70:
        stage = "Q9_COEVOLUTION"
    if case.hard_stage_cap in STAGE_ORDER and STAGE_ORDER.index(stage) > STAGE_ORDER.index(case.hard_stage_cap):
        stage = case.hard_stage_cap
    bottleneck = min((key for key in "DIKWPRHS"), key=lambda x: metrics[x])
    return stage, round(closure, 5), bottleneck


def semantic_efficiency(metrics: Mapping[str, float], channel: ChannelProfile, harm_penalty: float) -> float:
    # Context-specific "semantic work per normalized energy unit". It is not a universal meaning/energy conversion constant.
    useful_change = 0.22 * metrics["I"] + 0.30 * metrics["K"] + 0.18 * metrics["W"] + 0.20 * metrics["P"] + 0.10 * metrics["R"]
    cost = max(0.06, 1.15 - channel.energy_efficiency + 0.35 * channel.invasiveness + 0.30 * channel.latency)
    return round(clamp((useful_change - 0.55 * harm_penalty) / (0.70 + cost)), 5)
