from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone
from typing import Any, Dict, Mapping


def build_dikwp_packet(
    packet_id: str,
    sender_id: str,
    receiver_id: str,
    channel_id: str,
    data_payload: Mapping[str, Any],
    information_claims: Mapping[str, Any],
    knowledge_hypotheses: Mapping[str, Any],
    wisdom_constraints: Mapping[str, Any],
    purpose_request: Mapping[str, Any],
    reply_schema: Mapping[str, Any],
) -> Dict[str, Any]:
    packet = {
        "packet_id": packet_id,
        "protocol": "DIKWP-RESONANCE/1.0",
        "created_at": datetime.now(timezone.utc).isoformat(),
        "sender_id": sender_id,
        "receiver_id": receiver_id,
        "channel_id": channel_id,
        "D": dict(data_payload),
        "I": dict(information_claims),
        "K": dict(knowledge_hypotheses),
        "W": dict(wisdom_constraints),
        "P": dict(purpose_request),
        "reply_schema": dict(reply_schema),
    }
    canonical = json.dumps(packet, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    packet["sha256"] = hashlib.sha256(canonical.encode("utf-8")).hexdigest()
    return packet


def demo_packet(case_id: str, sender_id: str, receiver_id: str, channel_id: str) -> Dict[str, Any]:
    return build_dikwp_packet(
        packet_id=f"PKT-{case_id}-001",
        sender_id=sender_id,
        receiver_id=receiver_id,
        channel_id=channel_id,
        data_payload={
            "raw_samples": "hash://sample-bundle",
            "calibration": "included",
            "clock_model": "relative-epoch + uncertainty",
            "provenance": "signed",
        },
        information_claims={
            "segmentation_hypotheses": ["A", "B", "unknown"],
            "regularities": ["repeat", "contrast", "turn-boundary"],
            "confidence": 0.61,
        },
        knowledge_hypotheses={
            "causal_claim": "Pattern A predicts response class R under context C",
            "verification_experiment": "low-energy reversible probe #3",
            "counterexample_request": True,
        },
        wisdom_constraints={
            "reversibility_required": True,
            "welfare_or_viability_review": True,
            "identity_change_forbidden": True,
            "unrestricted_executable_code": False,
        },
        purpose_request={
            "requested_action": "choose one of three reversible responses",
            "refusal_allowed": True,
            "commitment_duration": "one interaction epoch",
        },
        reply_schema={
            "options": ["confirm", "deny", "ambiguous", "refuse", "propose_alternative"],
            "include_uncertainty": True,
            "include_observed_side_effects": True,
        },
    )
