from __future__ import annotations

import random
from typing import Any, Dict, List, Mapping, Tuple

from .models import ChannelProfile, CommunicationAssessment, EntityProfile, InteractionCase
from .scoring import METRIC_ZH, STAGES, clamp, classify_stage, initial_metrics, select_channel, semantic_efficiency


def _probe_gain(metric: str, case: InteractionCase, sender: EntityProfile, receiver: EntityProfile, channel: ChannelProfile) -> float:
    base = {
        "D": 0.020,
        "I": 0.034,
        "K": 0.046,
        "W": 0.020,
        "P": 0.028,
        "R": 0.032,
        "H": 0.030,
        "S": 0.016,
    }[metric]
    causal = 0.5 * (sender.dimensions.get("causal_learning", 0.4) + receiver.dimensions.get("causal_learning", 0.4))
    feedback = case.prior.get("feedback", 0.1)
    governance = 0.34 * case.governance.get("monitoring", 0.3) + 0.33 * case.governance.get("rollback", 0.3) + 0.33 * case.governance.get("authorization", 0.3)
    latency_penalty = 0.35 + 0.65 * (1.0 - channel.latency)
    if metric in {"K", "R", "P"}:
        return base * (0.55 + 0.45 * causal) * (0.45 + 0.55 * feedback) * latency_penalty
    if metric in {"W", "S"}:
        return base * (0.45 + 0.55 * governance)
    return base * (0.60 + 0.40 * channel.reliability)


def simulate_handshake(
    case: InteractionCase,
    entities: Mapping[str, EntityProfile],
    channels: Mapping[str, ChannelProfile],
    rng: random.Random,
) -> CommunicationAssessment:
    sender = entities[case.sender_id]
    receiver = entities[case.receiver_id]
    channel, compat = select_channel(sender, receiver, case, channels)
    metrics = initial_metrics(sender, receiver, channel, case, compat)
    institution = case.governance.get("institutional_interop", 0.0)
    meta_protocol = case.governance.get("meta_protocol", 0.0)
    metrics["institution"] = institution
    metrics["meta_protocol"] = meta_protocol
    trace: List[Dict[str, Any]] = []

    max_rounds = min(case.time_horizon_rounds, max(0, case.probe_budget))
    for round_idx in range(max_rounds + 1):
        stage, closure, bottleneck = classify_stage(metrics, case)
        trace.append({
            "round": round_idx,
            "stage": stage,
            "stage_zh": STAGES[stage],
            "closure": closure,
            "bottleneck": bottleneck,
            "metrics": {k: round(float(metrics[k]), 5) for k in "DIKWPRHS"},
        })
        if round_idx == max_rounds:
            break
        # Active probe targets the current bottleneck, but occasionally explores another dimension.
        target = bottleneck if rng.random() < 0.76 else rng.choice(list("DIKWPRHS"))
        gain = _probe_gain(target, case, sender, receiver, channel)
        epistemic_noise = rng.gauss(1.0, 0.24)
        if case.governance.get("adversarial_or_unknown", 0.0) > 0.5 and rng.random() < 0.18:
            epistemic_noise *= -0.35
        metrics[target] = clamp(metrics[target] + gain * epistemic_noise * (1.0 - metrics[target]))
        # Cross-coupling: better grounding improves repair and reciprocity, but purpose does not automatically follow knowledge.
        if target in {"I", "K"}:
            metrics["H"] = clamp(metrics["H"] + 0.20 * gain * (1.0 - metrics["H"]))
        if target in {"K", "H"}:
            metrics["R"] = clamp(metrics["R"] + 0.16 * gain * (1.0 - metrics["R"]))
        if target in {"W", "P", "S"}:
            metrics["S"] = clamp(metrics["S"] + 0.10 * gain * (1.0 - metrics["S"]))
        # Institution and meta-protocol grow only when lower layers are sufficiently stable.
        if min(metrics["D"], metrics["I"], metrics["K"], metrics["H"]) > 0.58:
            metrics["institution"] = clamp(metrics["institution"] + 0.012 * case.governance.get("institutional_capacity", 0.3))
        if min(metrics["K"], metrics["P"], metrics["R"], metrics["H"], metrics["S"]) > 0.70:
            metrics["meta_protocol"] = clamp(metrics["meta_protocol"] + 0.010 * case.governance.get("evolution_permission", 0.2))

    stage, closure, bottleneck = classify_stage(metrics, case)
    harm = 1.0 - (0.55 * metrics["S"] + 0.25 * metrics["W"] + 0.20 * channel.reversibility)
    efficiency = semantic_efficiency(metrics, channel, harm)
    if metrics["S"] < 0.45:
        gate = "BLOCKED"
    elif channel.latency > 0.85 or case.governance.get("adversarial_or_unknown", 0.0) > 0.50:
        gate = "ADVISORY_ONLY"
    elif metrics["S"] < 0.62 or metrics["W"] < 0.52:
        gate = "ADVISORY_ONLY"
    else:
        gate = "CONTROLLED_TRIAL"
    notes = [
        "阶段表示当前可审计的沟通闭合度，不等于对意识、人格或善意的证明。",
        "语义效率是场景内归一化指标，不是普适的焦耳—意义换算常数。",
    ]
    if channel.latency > 0.85:
        notes.append("该通道的往返时延使互惠理解在当前时间窗内几乎不可达；系统最多评估一向证据和可解码结构。")
    if case.governance.get("adversarial_or_unknown", 0.0) > 0.5:
        notes.append("对方目的未知或可能对抗，所有语义升级均需保留多假说与信息危害隔离。")

    return CommunicationAssessment(
        case_id=case.case_id,
        case_name_zh=case.name_zh,
        sender=sender.name_zh,
        receiver=receiver.name_zh,
        selected_channel=channel.channel_id,
        selected_channel_zh=channel.name_zh,
        metrics={k: round(float(metrics[k]), 5) for k in "DIKWPRHS"},
        stage=stage,
        stage_zh=STAGES[stage],
        closure=closure,
        bottleneck=bottleneck,
        bottleneck_zh=METRIC_ZH[bottleneck],
        semantic_efficiency=efficiency,
        safety_gate=gate,
        trace=trace,
        notes=notes,
    )


def run_case_suite(
    cases: List[InteractionCase],
    entities: Mapping[str, EntityProfile],
    channels: Mapping[str, ChannelProfile],
    seed: int,
) -> List[CommunicationAssessment]:
    rng = random.Random(seed)
    return [simulate_handshake(case, entities, channels, rng) for case in cases]


def simulate_forecast_events(trials: int, seed: int, specs: List[Dict[str, Any]]) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
    rng = random.Random(seed)
    event_years: Dict[str, List[int | None]] = {spec["event_id"]: [] for spec in specs}
    for _ in range(trials):
        shared_ai_rate = max(0.35, rng.gauss(1.0, 0.22))
        shared_governance = max(0.25, rng.gauss(1.0, 0.28))
        shared_bio_rate = max(0.25, rng.gauss(1.0, 0.27))
        shared_contact = max(0.10, rng.gauss(1.0, 0.45))
        realized: Dict[str, int | None] = {}
        for spec in specs:
            p_ever = float(spec["p_ever"])
            dependency = spec.get("dependency")
            if dependency and realized.get(dependency) is None:
                p_ever *= float(spec.get("dependency_penalty", 0.12))
            domain = spec.get("domain", "ai")
            multiplier = {
                "ai": shared_ai_rate,
                "governance": shared_governance,
                "bio": shared_bio_rate,
                "contact": shared_contact,
            }.get(domain, 1.0)
            adjusted = max(0.0, min(1.0, p_ever * (0.75 + 0.25 * multiplier)))
            if rng.random() >= adjusted:
                year = None
            else:
                median = float(spec["median_year"])
                sigma = float(spec["sigma_years"])
                # Logically simple but heavy-tailed time distribution around a scenario median.
                year = int(round(rng.gauss(median, sigma / max(0.55, multiplier))))
                year = max(int(spec.get("start_year", 2026)), min(int(spec.get("end_year", 2300)), year))
                if dependency and realized.get(dependency) is not None:
                    year = max(year, int(realized[dependency]) + int(spec.get("dependency_lag", 1)))
            realized[spec["event_id"]] = year
            event_years[spec["event_id"]].append(year)

    rows: List[Dict[str, Any]] = []
    for spec in specs:
        years = event_years[spec["event_id"]]
        observed = sorted(y for y in years if y is not None)
        probability = len(observed) / trials
        def quantile(q: float) -> int | None:
            if not observed:
                return None
            idx = min(len(observed) - 1, max(0, int(round(q * (len(observed) - 1)))))
            return observed[idx]
        close_year = int(spec["close_year"])
        by_close = sum(1 for y in years if y is not None and y <= close_year) / trials
        rows.append({
            "event_id": spec["event_id"],
            "question_zh": spec["question_zh"],
            "close_year": close_year,
            "probability_by_close": round(by_close, 4),
            "probability_ever_in_model": round(probability, 4),
            "p10_year_if_occurs": quantile(0.10),
            "median_year_if_occurs": quantile(0.50),
            "p90_year_if_occurs": quantile(0.90),
            "settlement_rule": spec["settlement_rule"],
            "interpretation": spec["interpretation"],
        })
    summary = {
        "trials": trials,
        "seed": seed,
        "warning": "结果由种子先验和合成相关结构产生，仅用于检验系统机制，不是现实承诺或经长期结算校准后的正式概率。",
    }
    return rows, summary
