from __future__ import annotations

from typing import Any, Dict, List


def build_contracts(rows: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    contracts: List[Dict[str, Any]] = []
    for row in rows:
        p = float(row["probability_by_close"])
        if p >= 0.65:
            thresholds = [
                {"probability": 0.65, "action": "进入标准草案、跨机构复现实验和监管沙盒"},
                {"probability": 0.80, "action": "建立独立审计、事故报告和公众沟通机制"},
            ]
        elif p >= 0.30:
            thresholds = [
                {"probability": 0.35, "action": "建立预防性研究联盟与最小数据标准"},
                {"probability": 0.60, "action": "启动受控实地试验和权利影响评估"},
            ]
        else:
            thresholds = [
                {"probability": 0.10, "action": "维持低成本监测和年度更新"},
                {"probability": 0.25, "action": "建立专门证据委员会和国际磋商预案"},
            ]
        contracts.append({
            "forecast_id": row["event_id"],
            "question_zh": row["question_zh"],
            "close_year": row["close_year"],
            "probability": p,
            "settlement_rule": row["settlement_rule"],
            "update_triggers": [
                "出现跨机构复现的能力跃迁或反例",
                "监管、伦理或权利制度正式采用相关定义",
                "关键通道的能量、时延、侵入性或可逆性指标发生数量级变化",
            ],
            "action_thresholds": thresholds,
            "interpretation": row["interpretation"],
        })
    return contracts
